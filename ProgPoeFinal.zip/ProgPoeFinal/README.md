# ProgPoe

How to use this program: 
1. Open Visual Studio Community.
2. Click on the 'Code' button in Github.
3. Once there click on Download Zip.
4. Once the zip file has been downloaded and extracted, in Visual Studio use the open function and select the ProgPoe file.
5. This will open the file in Visual Studio and then the code can be run by clicking the green play button.
6. The program should be working now.
7. Once the command line has popped up, there are a variety of options to choose from.
8. To select an option, type in the corresponding number.
9. Once an option is selected, there will be instructions on what to type or select.
10. Once the program has been used and the user wants to exit, they can simply type 4 or any number above 4 to close the application.
