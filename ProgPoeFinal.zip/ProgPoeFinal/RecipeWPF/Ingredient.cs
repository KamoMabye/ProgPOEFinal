﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgPoe
{
    public class Ingredient
    {

        public double ingrQuant { get; set; }
        public string ingrName { get; set; }
        public string ingrUnit { get; set; }
        public double ingrCal { get; set; }
        public string ingrFood { get; set; }
        public double totalCalories { get; set; }

    }
}
