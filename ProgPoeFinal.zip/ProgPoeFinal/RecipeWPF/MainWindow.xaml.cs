﻿using ProgPoe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {

            InitializeComponent();
        }

        private void CreateRecipe_MouseEnter(object sender, MouseEventArgs e)
        {
            CreateRecipe.BorderBrush = Brushes.WhiteSmoke;
            CreateRecipe.Foreground = Brushes.MidnightBlue;
            CreateRecipe.Cursor = Cursors.Hand;
        }

        private void CreateRecipe_MouseLeave(object sender, MouseEventArgs e)
        {
            CreateRecipe.BorderBrush = Brushes.White;
            CreateRecipe.Foreground = Brushes.White;
        }

        private void ShowRecipe_MouseEnter(object sender, MouseEventArgs e)
        {
            ShowRecipe.BorderBrush = Brushes.WhiteSmoke;
            ShowRecipe.Foreground = Brushes.MidnightBlue;
            ShowRecipe.Cursor = Cursors.Hand;
        }

        private void ShowRecipe_MouseLeave(object sender, MouseEventArgs e)
        {
            ShowRecipe.BorderBrush = Brushes.White;
            ShowRecipe.Foreground = Brushes.White;
        }

        private void ExitButton_MouseEnter(object sender, MouseEventArgs e)
        {
            ExitButton.BorderBrush = Brushes.WhiteSmoke;
            ExitButton.Foreground = Brushes.MidnightBlue;
            ExitButton.Cursor = Cursors.Hand;
        }

        private void ExitButton_MouseLeave(object sender, MouseEventArgs e)
        {
            ExitButton.BorderBrush = Brushes.White;
            ExitButton.Foreground = Brushes.White;
        }

        private void CreateRecipe_Click(object sender, RoutedEventArgs e)
        {
            
            IngredientWindow newIngredient = new IngredientWindow(recipes); // Create an instance of the new window

            // Close the main window
            this.Close();

            // Show the new window
            newIngredient.Show();
        }

        private void ShowRecipe_Click(object sender, RoutedEventArgs e)
        {
                MessageBox.Show("No recipes have been created. Please create a new recipe!");   
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
