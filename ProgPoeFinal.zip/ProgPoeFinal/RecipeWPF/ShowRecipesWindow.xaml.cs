﻿using ProgPoe;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeWPF
{
    /// <summary>
    /// Interaction logic for ShowRecipesWindow.xaml
    /// </summary>
    public partial class ShowRecipesWindow : Window
    {
        public List<Recipe> recipes;
        public Recipe recipe;
        public ShowRecipesWindow(Recipe recipe, List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            this.recipe = recipe;

        }

        private void show_Click(object sender, RoutedEventArgs e)
        {
            IngredientWindow newIngredient = new IngredientWindow(recipes);
            this.Close();
            newIngredient.Show();
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {


        }

        private void Create_MouseEnter(object sender, MouseEventArgs e)
        {
            Create.BorderBrush = Brushes.WhiteSmoke;
            Create.Foreground = Brushes.MidnightBlue;
            Create.Cursor = Cursors.Hand;
        }

        private void Create_MouseLeave(object sender, MouseEventArgs e)
        {
            Create.BorderBrush = Brushes.White;
            Create.Foreground = Brushes.White;
        }

        private void searchCal_MouseEnter(object sender, MouseEventArgs e)
        {
            searchCal.BorderBrush = Brushes.WhiteSmoke;
            searchCal.Foreground = Brushes.MidnightBlue;
            searchCal.Cursor = Cursors.Hand;
        }

        private void searchCal_MouseLeave(object sender, MouseEventArgs e)
        {
            searchCal.BorderBrush = Brushes.White;
            searchCal.Foreground = Brushes.White;
        }

        private void searchFood_MouseEnter(object sender, MouseEventArgs e)
        {
            searchFood.BorderBrush = Brushes.WhiteSmoke;
            searchFood.Foreground = Brushes.MidnightBlue;
            searchFood.Cursor = Cursors.Hand;
        }

        private void searchFood_MouseLeave(object sender, MouseEventArgs e)
        {
            searchFood.BorderBrush = Brushes.White;
            searchFood.Foreground = Brushes.White;
        }

        private void searchIngr_MouseEnter(object sender, MouseEventArgs e)
        {
            searchIngr.BorderBrush = Brushes.WhiteSmoke;
            searchIngr.Foreground = Brushes.MidnightBlue;
            searchIngr.Cursor = Cursors.Hand;
        }

        private void searchIngr_MouseLeave(object sender, MouseEventArgs e)
        {
            searchIngr.BorderBrush = Brushes.White;
            searchIngr.Foreground = Brushes.White;
        }

        private void searchIngr_Click(object sender, RoutedEventArgs e)
        {
            if (ingrNameSearch.Text.Equals(""))
            {
                MessageBox.Show("Please make sure the Ingredient Name box has been filled in!");
            }
            else
            {
                for (int i = 0; i < recipe.ingredient.Count; i++)
                {
                    if (ingrNameSearch.Text.Equals(recipe.recipeName))
                    {
                        foreach (Ingredient j in recipe.ingredient)
                        {
                            MessageBox.Show($"Here is your recipe:\n" +
                            $"Ingredients:\n" +
                            $"Ingr Name: {j.ingrName}\n" +
                            $"Ingr Quant: {j.ingrQuant}\n" +
                            $"Ingr Unit: {j.ingrUnit}\n" +
                            $"Ingr Cal: {j.ingrCal}\n" +
                            $"Ingr Food Group: {j.ingrFood}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("There are no recipes that contain this Ingredient Name!");
                    }
                }

            }
        }

        private void searchFood_Click(object sender, RoutedEventArgs e)
        {
            if (foodGrpSearch.Text.Equals(""))
            {
                MessageBox.Show("Please make sure the Food Grooup box has been selected!");
            }
            else
            {

                for (int i = 0; i < recipe.ingredient.Count; i++)
                {
                    if (foodGrpSearch.Text.Equals(recipe.recipeName))
                    {
                        foreach (Ingredient j in recipe.ingredient)
                        {
                            MessageBox.Show($"Here is your recipe:\n" +
                            $"Ingredients:\n" +
                            $"Ingr Name: {j.ingrName}\n" +
                            $"Ingr Quant: {j.ingrQuant}\n" +
                            $"Ingr Unit: {j.ingrUnit}\n" +
                            $"Ingr Cal: {j.ingrCal}\n" +
                            $"Ingr Food Group: {j.ingrFood}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("There are no recipes that contain this food group!");
                    }
                }

            }
        }
        private void searchCal_Click(object sender, RoutedEventArgs e)
        {
            if (ingrCalsSearch.Text.Equals(""))
            {
                MessageBox.Show("Please make sure the Maximum Calories box has been filled in!");
            }
            else
            {
                for (int i = 0; i < recipe.ingredient.Count; i++)
                {
                    if (ingrCalsSearch.Text.Equals(recipe.recipeName))
                    {
                        foreach (Ingredient j in recipe.ingredient)
                        {
                            MessageBox.Show($"Here is your recipe:\n" +
                            $"Ingredients:\n" +
                            $"Ingr Name: {j.ingrName}\n" +
                            $"Ingr Quant: {j.ingrQuant}\n" +
                            $"Ingr Unit: {j.ingrUnit}\n" +
                            $"Ingr Cal: {j.ingrCal}\n" +
                            $"Ingr Food Group: {j.ingrFood}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("There are no recipes that contain this maximum amount of calories!");
                    }
                }

            }
        }
    }
}
