﻿using ProgPoe;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeWPF
{
    /// <summary>
    /// Interaction logic for Recipe.xaml
    /// </summary>
    public partial class RecipeWindow : Window
    {
        public List<Recipe> recipes;
        public Recipe recipe;
        public RecipeWindow(Recipe recipe, List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            this.recipe = recipe;
        }

        private void AddRecipe_MouseEnter(object sender, MouseEventArgs e)
        {
            AddRecipe.BorderBrush = Brushes.WhiteSmoke;
            AddRecipe.Foreground = Brushes.MidnightBlue;
            AddRecipe.Cursor = Cursors.Hand;
        }

        private void AddRecipe_MouseLeave(object sender, MouseEventArgs e)
        {
            AddRecipe.BorderBrush = Brushes.White;
            AddRecipe.Foreground = Brushes.White;
        }

        private void ClearRecipe_MouseEnter(object sender, MouseEventArgs e)
        {
            ClearRecipe.BorderBrush = Brushes.WhiteSmoke;
            ClearRecipe.Foreground = Brushes.MidnightBlue;
            ClearRecipe.Cursor = Cursors.Hand;
        }

        private void ClearRecipe_MouseLeave(object sender, MouseEventArgs e)
        {
            ClearRecipe.BorderBrush = Brushes.White;
            ClearRecipe.Foreground = Brushes.White;
        }

        private void Create_MouseEnter(object sender, MouseEventArgs e)
        {
            Create.BorderBrush = Brushes.WhiteSmoke;
            Create.Foreground = Brushes.MidnightBlue;
            Create.Cursor = Cursors.Hand;
        }

        private void Create_MouseLeave(object sender, MouseEventArgs e)
        {
            Create.BorderBrush = Brushes.White;
            Create.Foreground = Brushes.White;
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeName.Text.Equals(""))
            {
                MessageBox.Show("Please make sure you name your recipe!");
            }
            else
            {
                
                recipe.recipeName = RecipeName.Text;
                recipes.Add(recipe);
                ShowRecipesWindow showRecipesWindow = new ShowRecipesWindow(recipe, recipes);
                this.Close();

                showRecipesWindow.Show();
            }

        }

        private void ClearRecipe_Click(object sender, RoutedEventArgs e)
        {
            StepsBox.Text = string.Empty;
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (StepsBox.Text.Equals(""))
            {
                MessageBox.Show("Please make sure all boxes have been filled in!");
            }
            else
            {
                MessageBox.Show("Step has been added!");
                recipe.Steps.Add(StepsBox.Text);
            }
        }
    }
}
