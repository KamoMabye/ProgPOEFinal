﻿using ProgPoe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeWPF
{
    /// <summary>
    /// Interaction logic for Ingredient.xaml
    /// </summary>
    public partial class IngredientWindow : Window
    {
        public List<Recipe> recipes;
        Recipe recipe = new Recipe();

        public IngredientWindow( List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            

        }

        private void AddIngr_MouseEnter(object sender, MouseEventArgs e)
        {
            AddIngr.BorderBrush = Brushes.WhiteSmoke;
            AddIngr.Foreground = Brushes.MidnightBlue;
            AddIngr.Cursor = Cursors.Hand;
        }

        private void AddIngr_MouseLeave(object sender, MouseEventArgs e)
        {
            AddIngr.BorderBrush = Brushes.White;
            AddIngr.Foreground = Brushes.White;
            
            
        }

        private void AddIngr_Click(object sender, RoutedEventArgs e)
        {
            
            
            if (ingrNames.Text.Equals("") || ingrCals.Text.Equals("") || ingrQuants.Text.Equals("") || ingrUnits.Text.Equals("") || foodGrps.Text.Equals(""))
            {
                MessageBox.Show("Please make sure all boxes have been filled in!");
            }
            else
            {
                Ingredient ingr = new Ingredient();
                ingr.ingrName = ingrNames.Text;
                ingr.ingrQuant = Convert.ToDouble(ingrQuants.Text);
                ingr.ingrUnit = ingrUnits.Text;
                ingr.ingrCal = Convert.ToDouble(ingrCals.Text);
                ingr.ingrFood = foodGrps.Text;
                recipe.ingredient.Add(ingr);
                MessageBox.Show("Ingredient successfully added!");
            }
            

        }

        private void CreateSteps_MouseEnter(object sender, MouseEventArgs e)
        {
            CreateSteps.BorderBrush = Brushes.WhiteSmoke;
            CreateSteps.Foreground = Brushes.MidnightBlue;
            CreateSteps.Cursor = Cursors.Hand;
        }

        private void CreateSteps_MouseLeave(object sender, MouseEventArgs e)
        {
            CreateSteps.BorderBrush = Brushes.White;
            CreateSteps.Foreground = Brushes.White;
        }

        private void ClearIngr_MouseEnter(object sender, MouseEventArgs e)
        {
            ClearIngr.BorderBrush = Brushes.WhiteSmoke;
            ClearIngr.Foreground = Brushes.MidnightBlue;
            ClearIngr.Cursor = Cursors.Hand;
        }

        private void ClearIngr_MouseLeave(object sender, MouseEventArgs e)
        {
            ClearIngr.BorderBrush = Brushes.White;
            ClearIngr.Foreground = Brushes.White;
        }

        private void CreateSteps_Click(object sender, RoutedEventArgs e)
        {
            RecipeWindow newRecipe = new RecipeWindow(recipe, recipes); // Create an instance of the new window

            // Close the main window
            this.Close();

            // Show the new window
            newRecipe.Show();
        }

        private void ClearIngr_Click(object sender, RoutedEventArgs e)
        {
            ingrNames.Text = string.Empty;
            ingrQuants.Text = string.Empty;
            ingrUnits.Text = string.Empty;
            ingrCals.Text = string.Empty;
            foodGrps.Text = string.Empty;
            MessageBox.Show("Ingredient has been cleared!");
        }

       
    }
}
