namespace POEUnitTests
{
    public class RecipeTest
    {
        [SetUp]
        public void Setup()
        {
            List<double> ingrCal = new List<double>();
            List<double> total = new List<double>();

        }

        [Test]
        public void calCalculationTest()
        {
            Assert.Pass();
        }
    }
}